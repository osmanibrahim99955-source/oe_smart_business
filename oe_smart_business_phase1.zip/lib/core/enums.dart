import 'package:flutter/material.dart';

enum PaymentMethod { cash, bankak, okash, fawry, ajel }
enum VaultApp { bankak, okash, fawry }

extension PaymentMethodX on PaymentMethod {
  String get label => switch (this) {
        PaymentMethod.cash => 'كاش',
        PaymentMethod.bankak => 'بنكك',
        PaymentMethod.okash => 'أوكاش',
        PaymentMethod.fawry => 'فوري',
        PaymentMethod.ajel => 'آجل',
      };
  IconData get icon => switch (this) {
        PaymentMethod.cash => Icons.payments_outlined,
        PaymentMethod.bankak => Icons.account_balance_outlined,
        PaymentMethod.okash => Icons.account_balance_wallet_outlined,
        PaymentMethod.fawry => Icons.bolt,
        PaymentMethod.ajel => Icons.schedule,
      };
  Color get color => switch (this) {
        PaymentMethod.cash => const Color(0xFFEAE6DA),
        PaymentMethod.bankak => const Color(0xFF3FB68B),
        PaymentMethod.okash => const Color(0xFF4FA3E3),
        PaymentMethod.fawry => const Color(0xFFE8C15A),
        PaymentMethod.ajel => const Color(0xFF8B9098),
      };
  bool get isElectronic =>
      this == PaymentMethod.bankak ||
      this == PaymentMethod.okash ||
      this == PaymentMethod.fawry;
  VaultApp? get vaultApp => switch (this) {
        PaymentMethod.bankak => VaultApp.bankak,
        PaymentMethod.okash => VaultApp.okash,
        PaymentMethod.fawry => VaultApp.fawry,
        _ => null,
      };
}

extension VaultAppX on VaultApp {
  String get label => switch (this) {
        VaultApp.bankak => 'بنكك',
        VaultApp.okash => 'أوكاش',
        VaultApp.fawry => 'فوري',
      };
  String get enLabel => switch (this) {
        VaultApp.bankak => 'Bankak',
        VaultApp.okash => 'O-Kash',
        VaultApp.fawry => 'Fawry',
      };
  IconData get icon => switch (this) {
        VaultApp.bankak => Icons.account_balance_outlined,
        VaultApp.okash => Icons.account_balance_wallet_outlined,
        VaultApp.fawry => Icons.bolt,
      };
  Color get color => switch (this) {
        VaultApp.bankak => const Color(0xFF3FB68B),
        VaultApp.okash => const Color(0xFF4FA3E3),
        VaultApp.fawry => const Color(0xFFE8C15A),
      };
}
