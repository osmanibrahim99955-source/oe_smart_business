import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const bg = Color(0xFF0B0E14);
  static const card = Color(0xFF151A21);
  static const cardBorder = Color(0x33E8C15A);
  static const gold = Color(0xFFE8C15A);
  static const goldDark = Color(0xFFC9A227);
  static const text = Color(0xFFEAE6DA);
  static const muted = Color(0xFF8B9098);
  static const green = Color(0xFF3FB68B);
  static const red = Color(0xFFE5534B);
  static const blue = Color(0xFF4FA3E3);
  static const amber = Color(0xFFE8C15A);
}

ThemeData get appTheme {
  final base = ThemeData.dark(useMaterial3: true);
  final textTheme = GoogleFonts.cairoTextTheme(base.textTheme);
  return base.copyWith(
    scaffoldBackgroundColor: AppColors.bg,
    textTheme: textTheme,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.gold,
      secondary: AppColors.green,
      surface: AppColors.card,
      error: AppColors.red,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.card,
      hintStyle: textTheme.bodyMedium?.copyWith(color: AppColors.muted),
      labelStyle: const TextStyle(color: AppColors.gold),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.cardBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.cardBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.gold, width: 1.4),
      ),
    ),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: AppColors.card,
      contentTextStyle: TextStyle(color: AppColors.text),
      behavior: SnackBarBehavior.floating,
    ),
  );
}

void toast(BuildContext context, String message, {bool isError = false}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message, textAlign: TextAlign.right),
      backgroundColor: isError ? AppColors.red : AppColors.card,
    ),
  );
}

String fmt(double v) {
  final s = v.toStringAsFixed(v.truncateToDouble() == v ? 0 : 2);
  final parts = s.split('.');
  final intPart = parts[0].replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  return parts.length > 1 && parts[1] != '0' ? '$intPart.${parts[1]}' : intPart;
}
