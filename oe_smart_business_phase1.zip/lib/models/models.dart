import '../core/enums.dart';

class Product {
  String id;
  String name;
  String barcode;
  int quantity;
  int minLevel;
  double costPrice;
  double salePrice;
  Product({
    required this.id,
    required this.name,
    this.barcode = '',
    this.quantity = 0,
    this.minLevel = 0,
    this.costPrice = 0,
    this.salePrice = 0,
  });
  Map<String, dynamic> toJson() => {
        'id': id, 'name': name, 'barcode': barcode, 'quantity': quantity,
        'minLevel': minLevel, 'costPrice': costPrice, 'salePrice': salePrice,
      };
  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: j['id'], name: j['name'], barcode: j['barcode'] ?? '',
        quantity: j['quantity'] ?? 0, minLevel: j['minLevel'] ?? 0,
        costPrice: (j['costPrice'] ?? 0).toDouble(),
        salePrice: (j['salePrice'] ?? 0).toDouble(),
      );
}

class InvoiceItem {
  String name;
  int qty;
  double price;
  InvoiceItem({required this.name, this.qty = 1, this.price = 0});
  double get total => qty * price;
  Map<String, dynamic> toJson() => {'name': name, 'qty': qty, 'price': price};
  factory InvoiceItem.fromJson(Map<String, dynamic> j) => InvoiceItem(
      name: j['name'], qty: j['qty'] ?? 1, price: (j['price'] ?? 0).toDouble());
}

class Invoice {
  String id;
  DateTime date;
  String customerName;
  String customerPhone;
  List<InvoiceItem> items;
  PaymentMethod method;
  String txnLast4;
  double total;
  double profit;
  bool paid;
  Invoice({
    required this.id,
    required this.date,
    this.customerName = '',
    this.customerPhone = '',
    required this.items,
    this.method = PaymentMethod.cash,
    this.txnLast4 = '',
    this.total = 0,
    this.profit = 0,
    this.paid = true,
  });
  Map<String, dynamic> toJson() => {
        'id': id, 'date': date.toIso8601String(), 'customerName': customerName,
        'customerPhone': customerPhone,
        'items': items.map((e) => e.toJson()).toList(),
        'method': method.name, 'txnLast4': txnLast4, 'total': total,
        'profit': profit, 'paid': paid,
      };
  factory Invoice.fromJson(Map<String, dynamic> j) => Invoice(
        id: j['id'], date: DateTime.parse(j['date']),
        customerName: j['customerName'] ?? '', customerPhone: j['customerPhone'] ?? '',
        items: (j['items'] as List).map((e) => InvoiceItem.fromJson(e)).toList(),
        method: PaymentMethod.values.firstWhere((m) => m.name == j['method'],
            orElse: () => PaymentMethod.cash),
        txnLast4: j['txnLast4'] ?? '', total: (j['total'] ?? 0).toDouble(),
        profit: (j['profit'] ?? 0).toDouble(), paid: j['paid'] ?? true,
      );
}

class VaultTransaction {
  String id;
  VaultApp app;
  double amount;
  String txnRef; // آخر 4 أرقام أو رقم الإشعار كاملاً
  String sender;
  DateTime date;
  String source; // 'capture' | 'manual' | 'sale'
  VaultTransaction({
    required this.id,
    required this.app,
    required this.amount,
    this.txnRef = '',
    this.sender = '',
    required this.date,
    this.source = 'manual',
  });
  Map<String, dynamic> toJson() => {
        'id': id, 'app': app.name, 'amount': amount, 'txnRef': txnRef,
        'sender': sender, 'date': date.toIso8601String(), 'source': source,
      };
  factory VaultTransaction.fromJson(Map<String, dynamic> j) => VaultTransaction(
        id: j['id'],
        app: VaultApp.values.firstWhere((a) => a.name == j['app'],
            orElse: () => VaultApp.bankak),
        amount: (j['amount'] ?? 0).toDouble(), txnRef: j['txnRef'] ?? '',
        sender: j['sender'] ?? '', date: DateTime.parse(j['date']),
        source: j['source'] ?? 'manual',
      );
}
