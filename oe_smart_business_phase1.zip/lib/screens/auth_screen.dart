import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import '../state/app_state.dart';
import 'business_setup_screen.dart';
import 'main_shell.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool isRegister = false;
  final name = TextEditingController();
  final email = TextEditingController();
  final pass = TextEditingController();

  void _goNext(BuildContext context) {
    final state = context.read<AppState>();
    state.setUser(
      name: isRegister && name.text.isNotEmpty ? name.text : (email.text.split('@').first),
      email: email.text.isNotEmpty ? email.text : state.userEmail,
    );
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => state.setupDone ? const MainShell() : const BusinessSetupScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            const SizedBox(height: 20),
            Row(children: [
              IconButton(
                icon: const Icon(Icons.close, color: AppColors.muted),
                onPressed: () => Navigator.pop(context),
              ),
              const Spacer(),
              const Text('OE Smart Business',
                  style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.w800, fontSize: 16)),
              const SizedBox(width: 10),
              const OELogo(size: 34),
            ]),
            const SizedBox(height: 24),
            OECard(
              child: Column(children: [
                Row(children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => setState(() => isRegister = false),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: !isRegister ? AppColors.gold.withOpacity(0.15) : Colors.transparent,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: !isRegister ? AppColors.gold : AppColors.cardBorder),
                        ),
                        child: Text('تسجيل الدخول',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: !isRegister ? AppColors.gold : AppColors.muted, fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => setState(() => isRegister = true),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: isRegister ? AppColors.gold.withOpacity(0.15) : Colors.transparent,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: isRegister ? AppColors.gold : AppColors.cardBorder),
                        ),
                        child: Text('إنشاء حساب',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: isRegister ? AppColors.gold : AppColors.muted, fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
                ]),
                const SizedBox(height: 20),
                if (isRegister) ...[
                  TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم الظاهر (اختياري)')),
                  const SizedBox(height: 12),
                ],
                TextField(controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: 'البريد الإلكتروني', hintText: 'you@example.com')),
                const SizedBox(height: 12),
                TextField(controller: pass,
                    obscureText: true,
                    decoration: const InputDecoration(labelText: 'كلمة المرور', hintText: '6 أحرف على الأقل')),
                const SizedBox(height: 20),
                GoldButton(
                  label: isRegister ? 'إنشاء حساب' : 'تسجيل الدخول',
                  icon: isRegister ? Icons.person_add_alt : Icons.login,
                  onPressed: () {
                    if (email.text.trim().isEmpty) {
                      toast(context, 'أدخل البريد الإلكتروني', isError: true);
                      return;
                    }
                    _goNext(context);
                  },
                ),
                const SizedBox(height: 14),
                const Row(children: [
                  Expanded(child: Divider(color: AppColors.cardBorder)),
                  Padding(padding: EdgeInsets.symmetric(horizontal: 10),
                      child: Text('أو', style: TextStyle(color: AppColors.muted, fontSize: 12))),
                  Expanded(child: Divider(color: AppColors.cardBorder)),
                ]),
                const SizedBox(height: 14),
                GoldButton(
                  label: 'المتابعة عبر Google',
                  icon: Icons.g_mobiledata,
                  outline: true,
                  onPressed: () {
                    // الربط الحقيقي بحساب Google يأتي مع Firebase في مرحلة المزامنة
                    _goNext(context);
                  },
                ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
