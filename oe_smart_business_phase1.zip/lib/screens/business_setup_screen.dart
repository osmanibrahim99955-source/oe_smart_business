import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import '../state/app_state.dart';
import 'main_shell.dart';

class BusinessSetupScreen extends StatefulWidget {
  const BusinessSetupScreen({super.key});
  @override
  State<BusinessSetupScreen> createState() => _BusinessSetupScreenState();
}

class _BusinessSetupScreenState extends State<BusinessSetupScreen> {
  final name = TextEditingController();
  final policy = TextEditingController(
      text: 'البضاعة المباعة لا تُرد ولا تُستبدل بعد 3 أيام من تاريخ الفاتورة.');
  String type = 'تجارة عامة';
  final types = ['تجارة عامة', 'مواد غذائية', 'قطع غيار', 'ملابس', 'مزرعة', 'أخرى'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SizedBox(height: 24),
            const Center(child: OELogo(size: 80)),
            const SizedBox(height: 18),
            const Center(child: Text('إعداد النشاط التجاري',
                style: TextStyle(color: AppColors.text, fontSize: 22, fontWeight: FontWeight.w800))),
            const SizedBox(height: 6),
            const Center(child: Text('أدخل بيانات نشاطك — يمكنك تعديلها من الإعدادات في أي وقت',
                style: TextStyle(color: AppColors.muted, fontSize: 13))),
            const SizedBox(height: 24),
            OECard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('اسم النشاط *', style: TextStyle(color: AppColors.gold)),
              const SizedBox(height: 8),
              TextField(controller: name, decoration: const InputDecoration(hintText: 'مثال: مزرعة ابراهيم حسن')),
              const SizedBox(height: 16),
              const Text('نوع النشاط', style: TextStyle(color: AppColors.gold)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: type,
                dropdownColor: AppColors.card,
                decoration: const InputDecoration(),
                items: types.map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
                onChanged: (v) => setState(() => type = v!),
              ),
              const SizedBox(height: 16),
              const Text('شروط الإرجاع الافتراضية بالفاتورة', style: TextStyle(color: AppColors.gold)),
              const SizedBox(height: 8),
              TextField(controller: policy, maxLines: 3),
              const SizedBox(height: 22),
              GoldButton(
                label: 'حفظ والبدء',
                icon: Icons.rocket_launch_outlined,
                onPressed: () {
                  if (name.text.trim().isEmpty) {
                    toast(context, 'أدخل اسم النشاط', isError: true);
                    return;
                  }
                  context.read<AppState>().completeSetup(
                      name: name.text.trim(), type: type, policy: policy.text.trim());
                  Navigator.pushAndRemoveUntil(
                    context, MaterialPageRoute(builder: (_) => const MainShell()), (_) => false);
                },
              ),
            ])),
          ]),
        ),
      ),
    );
  }
}
