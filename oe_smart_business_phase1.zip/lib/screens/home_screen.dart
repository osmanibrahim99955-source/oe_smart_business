import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme.dart';
import '../core/enums.dart';
import '../widgets/common.dart';
import '../state/app_state.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  final VoidCallback onOpenInventory;
  const HomeScreen({super.key, required this.onOpenInventory});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            AppHeader(title: 'OE Smart Business', subtitle: s.businessName,
                onSettings: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
            const SizedBox(height: 14),
            // بطاقة النشاط
            OECard(child: Column(children: [
              Row(children: [
                const OELogo(size: 52),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(s.businessName, style: const TextStyle(color: AppColors.text, fontSize: 18, fontWeight: FontWeight.w800)),
                  Text('${s.businessType} · OE Smart Business',
                      style: const TextStyle(color: AppColors.gold, fontSize: 12)),
                ])),
              ]),
              const SizedBox(height: 12),
              const Text('صُمم هذا النظام ليمنحك السيطرة المالية الكاملة والوضوح التام في إدارة تجارتك يومياً.',
                  style: TextStyle(color: AppColors.muted, fontSize: 12, height: 1.6)),
              const SizedBox(height: 10),
              Row(children: [
                const Spacer(),
                Text('تطوير: ', style: const TextStyle(color: AppColors.muted, fontSize: 11)),
                Text(s.developer, style: const TextStyle(color: AppColors.gold, fontSize: 11, fontWeight: FontWeight.w700)),
                const SizedBox(width: 6),
                const OELogo(size: 18),
              ]),
            ])),
            const SizedBox(height: 20),
            const Text('حركة اليوم', style: TextStyle(color: AppColors.text, fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            Row(children: [
              StatCard(label: 'مبيعات اليوم', value: '${fmt(s.todaySales)} ج.س', icon: Icons.trending_up, iconColor: AppColors.gold),
              const SizedBox(width: 10),
              StatCard(label: 'صافي أرباح اليوم', value: '${fmt(s.todayProfit)} ج.س', icon: Icons.trending_up, iconColor: AppColors.green),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              StatCard(label: 'مبيعات الشهر', value: '${fmt(s.monthSales)} ج.س', icon: Icons.calendar_month_outlined, iconColor: AppColors.gold),
              const SizedBox(width: 10),
              StatCard(label: 'فواتير اليوم', value: '${s.todayInvoicesCount} فاتورة', icon: Icons.receipt_long, iconColor: AppColors.gold),
            ]),
            const SizedBox(height: 14),
            // الديون الآجلة
            OECard(borderColor: AppColors.amber.withOpacity(0.5), child: Row(children: [
              const Icon(Icons.warning_amber_rounded, color: AppColors.amber),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('إجمالي الديون الآجلة', style: TextStyle(color: AppColors.muted, fontSize: 12)),
                Text('${fmt(s.debtsTotal)} ج.س', style: const TextStyle(color: AppColors.amber, fontSize: 18, fontWeight: FontWeight.w800)),
              ])),
            ])),
            const SizedBox(height: 14),
            // السيولة الإلكترونية
            OECard(child: Column(children: [
              const Row(children: [
                Icon(Icons.savings_outlined, color: AppColors.green),
                SizedBox(width: 8),
                Text('السيولة الإلكترونية الشاملة', style: TextStyle(color: AppColors.muted, fontSize: 13)),
              ]),
              const SizedBox(height: 8),
              Text('${fmt(s.vaultGrand)} ج.س',
                  style: const TextStyle(color: AppColors.green, fontSize: 26, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              Row(children: VaultApp.values.map((a) => Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: AppColors.bg,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: a.color.withOpacity(0.4)),
                    ),
                    child: Column(children: [
                      Icon(a.icon, color: a.color, size: 18),
                      Text(a.label, style: TextStyle(color: a.color, fontSize: 11)),
                      Text(fmt(s.vaultTotal(a)), style: const TextStyle(color: AppColors.text, fontSize: 12, fontWeight: FontWeight.w700)),
                    ]),
                  ),
                ),
              )).toList()),
            ])),
            if (s.lowStock.isNotEmpty) ...[
              const SizedBox(height: 14),
              OECard(borderColor: AppColors.red.withOpacity(0.5), child: Column(children: [
                Row(children: [
                  const Icon(Icons.warning_amber_rounded, color: AppColors.red),
                  const SizedBox(width: 8),
                  Expanded(child: Text('تنبيهات نفاذ المخزون (${s.lowStock.length})',
                      style: const TextStyle(color: AppColors.red, fontWeight: FontWeight.w700))),
                ]),
                const SizedBox(height: 8),
                ...s.lowStock.take(3).map((p) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(children: [
                    Expanded(child: Text(p.name, style: const TextStyle(color: AppColors.text, fontSize: 13))),
                    Text('متبقي ${p.quantity}', style: const TextStyle(color: AppColors.red, fontSize: 12)),
                  ]),
                )),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton(
                    onPressed: onOpenInventory,
                    child: const Text('عرض المخزون', style: TextStyle(color: AppColors.gold)),
                  ),
                ),
              ])),
            ],
            const SizedBox(height: 20),
          ]),
        ),
      ),
    );
  }
}
