import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import '../state/app_state.dart';
import '../models/models.dart';

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});
  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  String query = '';

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final list = s.products.where((p) => p.name.contains(query) || p.barcode.contains(query)).toList();
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('المخزون', style: TextStyle(color: AppColors.text, fontSize: 20, fontWeight: FontWeight.w800)),
                Text('تحكم مطلق بإضافتك أنت', style: TextStyle(color: AppColors.muted, fontSize: 12)),
              ])),
              GoldButton(label: 'صنف جديد', icon: Icons.add, expand: false,
                  onPressed: () => showModalBottomSheet(
                      context: context, isScrollControlled: true,
                      backgroundColor: Colors.transparent,
                      builder: (_) => const ProductSheet())),
            ]),
            const SizedBox(height: 12),
            TextField(
              onChanged: (v) => setState(() => query = v),
              decoration: const InputDecoration(
                hintText: 'ابحث بالاسم أو الباركود...',
                prefixIcon: Icon(Icons.search, color: AppColors.muted),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: list.isEmpty
                  ? OECard(child: Column(children: [
                      const Icon(Icons.inventory_2_outlined, color: AppColors.gold, size: 48),
                      const SizedBox(height: 12),
                      const Text('المخزن فارغ — كما أردته', style: TextStyle(color: AppColors.text, fontSize: 16, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 6),
                      const Text('أضف أصنافك بنفسك: الاسم، الكمية، سعر التكلفة وسعر البيع — لك التحكم المطلق.',
                          textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 12, height: 1.6)),
                    ]))
                  : ListView.separated(
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) {
                        final p = list[i];
                        final low = p.minLevel > 0 && p.quantity <= p.minLevel;
                        return OECard(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12), child: Row(children: [
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(p.name, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w700)),
                            const SizedBox(height: 4),
                            Text('الكمية: ${p.quantity} · التكلفة: ${fmt(p.costPrice)} · البيع: ${fmt(p.salePrice)}',
                                style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                            if (low)
                              Text('⚠ منخفض — الحد الأدنى ${p.minLevel}',
                                  style: const TextStyle(color: AppColors.red, fontSize: 11)),
                          ])),
                          IconButton(
                            icon: const Icon(Icons.edit_outlined, color: AppColors.gold, size: 20),
                            onPressed: () => showModalBottomSheet(
                                context: context, isScrollControlled: true,
                                backgroundColor: Colors.transparent,
                                builder: (_) => ProductSheet(product: p)),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline, color: AppColors.red, size: 20),
                            onPressed: () => s.deleteProduct(p.id),
                          ),
                        ]));
                      }),
            ),
          ]),
        ),
      ),
    );
  }
}

class ProductSheet extends StatefulWidget {
  final Product? product;
  const ProductSheet({super.key, this.product});
  @override
  State<ProductSheet> createState() => _ProductSheetState();
}

class _ProductSheetState extends State<ProductSheet> {
  late final name = TextEditingController(text: widget.product?.name ?? '');
  late final barcode = TextEditingController(text: widget.product?.barcode ?? '');
  late final qty = TextEditingController(text: '${widget.product?.quantity ?? 0}');
  late final min = TextEditingController(text: '${widget.product?.minLevel ?? 0}');
  late final cost = TextEditingController(text: '${widget.product?.costPrice ?? 0}');
  late final sale = TextEditingController(text: '${widget.product?.salePrice ?? 0}');

  @override
  Widget build(BuildContext context) {
    final s = context.read<AppState>();
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: const BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(top: BorderSide(color: AppColors.cardBorder)),
        ),
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              IconButton(icon: const Icon(Icons.close, color: AppColors.muted), onPressed: () => Navigator.pop(context)),
              const Spacer(),
              Text(widget.product == null ? 'إضافة صنف' : 'تعديل صنف',
                  style: const TextStyle(color: AppColors.text, fontSize: 17, fontWeight: FontWeight.w800)),
            ]),
            const SizedBox(height: 12),
            const Text('اسم الصنف *', style: TextStyle(color: AppColors.gold)),
            const SizedBox(height: 8),
            TextField(controller: name, decoration: const InputDecoration(hintText: 'مثال: أرز بسمتي 5 كجم')),
            const SizedBox(height: 14),
            const Text('الباركود', style: TextStyle(color: AppColors.gold)),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: TextField(controller: barcode, decoration: const InputDecoration(hintText: 'امسح بالكاميرا أو أدخله يدوياً'))),
              const SizedBox(width: 8),
              GoldButton(label: 'مسح', icon: Icons.qr_code_scanner, expand: false,
                  onPressed: () => toast(context, 'الماسح الضوئي يُفعّل في مرحلة الإدخال الذكي')),
            ]),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('الكمية', style: TextStyle(color: AppColors.gold)),
                const SizedBox(height: 8),
                TextField(controller: qty, keyboardType: TextInputType.number),
              ])),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('الحد الأدنى للتنبيه', style: TextStyle(color: AppColors.gold)),
                const SizedBox(height: 8),
                TextField(controller: min, keyboardType: TextInputType.number),
              ])),
            ]),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('سعر التكلفة (ج.س)', style: TextStyle(color: AppColors.gold)),
                const SizedBox(height: 8),
                TextField(controller: cost, keyboardType: TextInputType.number),
              ])),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('سعر البيع * (ج.س)', style: TextStyle(color: AppColors.gold)),
                const SizedBox(height: 8),
                TextField(controller: sale, keyboardType: TextInputType.number),
              ])),
            ]),
            const SizedBox(height: 20),
            GoldButton(label: 'حفظ', icon: Icons.save_outlined, onPressed: () {
              if (name.text.trim().isEmpty || (double.tryParse(sale.text) ?? 0) <= 0) {
                toast(context, 'أدخل اسم الصنف وسعر البيع', isError: true);
                return;
              }
              final p = Product(
                id: widget.product?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
                name: name.text.trim(), barcode: barcode.text.trim(),
                quantity: int.tryParse(qty.text) ?? 0,
                minLevel: int.tryParse(min.text) ?? 0,
                costPrice: double.tryParse(cost.text) ?? 0,
                salePrice: double.tryParse(sale.text) ?? 0,
              );
              if (widget.product == null) { s.addProduct(p); } else { s.updateProduct(p); }
              Navigator.pop(context);
            }),
            const SizedBox(height: 10),
          ]),
        ),
      ),
    );
  }
}
