import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../core/theme.dart';
import '../core/enums.dart';
import '../widgets/common.dart';
import '../state/app_state.dart';
import '../models/models.dart';

class InvoiceDetailScreen extends StatefulWidget {
  final Invoice invoice;
  const InvoiceDetailScreen({super.key, required this.invoice});
  @override
  State<InvoiceDetailScreen> createState() => _InvoiceDetailScreenState();
}

class _InvoiceDetailScreenState extends State<InvoiceDetailScreen> {
  late final Invoice inv = widget.invvoice;
  late final customer = TextEditingController(text: inv.customerName);
  late final phone = TextEditingController(text: inv.customerPhone);
  late final policy = TextEditingController();

  @override
  void initState() {
    super.initState();
    policy.text = context.read<AppState>().returnPolicy;
  }

  double get total => inv.items.fold(0.0, (s, i) => s + i.total);

  void _save(BuildContext context) {
    inv.customerName = customer.text.trim();
    inv.customerPhone = phone.text.trim();
    inv.total = total;
    context.read<AppState>().updateInvoice(inv);
    toast(context, '✓ تم حفظ التعديلات');
  }

  Future<void> _editItem(int i) async {
    final qty = TextEditingController(text: '${inv.items[i].qty}');
    final price = TextEditingController(text: '${inv.items[i].price}');
    final r = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: AppColors.card,
      title: Text('تعديل: ${inv.items[i].name}', style: const TextStyle(color: AppColors.text, fontSize: 15)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الكمية')),
        const SizedBox(height: 10),
        TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعر')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء', style: TextStyle(color: AppColors.muted))),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ', style: TextStyle(color: AppColors.gold))),
      ],
    ));
    if (r == true) {
      setState(() {
        inv.items[i].qty = int.tryParse(qty.text) ?? inv.items[i].qty;
        inv.items[i].price = double.tryParse(price.text) ?? inv.items[i].price;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 10, 16, 4),
            child: Row(children: [
              IconButton(icon: const Icon(Icons.close, color: AppColors.muted), onPressed: () => Navigator.pop(context)),
              const Spacer(),
              Text('فاتورة ${inv.id}', style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w800)),
              const SizedBox(width: 12),
              const OELogo(size: 32),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Expanded(child: GoldButton(label: 'حفظ التعديلات', icon: Icons.save_outlined, expand: false, onPressed: () => _save(context))),
              const SizedBox(width: 8),
              Expanded(child: GoldButton(label: 'طباعة ورقية', icon: Icons.print_outlined, outline: true, expand: false,
                  onPressed: () => toast(context, 'تُفعّل الطباعة الرسمية (إخفاء واجهة التطبيق) في الربط النهائي'))),
              const SizedBox(width: 8),
              Expanded(child: GoldButton(label: 'تنزيل PDF', icon: Icons.download_outlined, outline: true, expand: false,
                  onPressed: () => toast(context, 'تُفعّل حزمة printing في المرحلة القادمة'))),
            ]),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: const Color(0xFFF5F1E6),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: DefaultTextStyle(
                  style: const TextStyle(color: Color(0xFF1A1A1A), fontSize: 13),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const OELogo(size: 44),
                      const SizedBox(width: 10),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(s.businessName, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                        Text(s.businessType, style: const TextStyle(fontSize: 11)),
                      ])),
                      Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                        Text('#${inv.id}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
                        Text('${DateFormat('yyyy-MM-dd').format(inv.date)} · ${DateFormat('HH:mm').format(inv.date)}',
                            style: const TextStyle(fontSize: 11)),
                      ]),
                    ]),
                    const Divider(color: Color(0xFFB08D2E), thickness: 1.2, height: 24),
                    Row(children: [
                      Expanded(child: TextField(controller: customer,
                          decoration: const InputDecoration(labelText: 'العميل', isDense: true,
                              fillColor: Colors.transparent, border: UnderlineInputBorder()))),
                      const SizedBox(width: 12),
                      Expanded(child: TextField(controller: phone,
                          decoration: const InputDecoration(labelText: 'الهاتف', isDense: true,
                              fillColor: Colors.transparent, border: UnderlineInputBorder()))),
                    ]),
                    const SizedBox(height: 6),
                    Row(children: [
                      const Text('طريقة الدفع: ', style: TextStyle(fontWeight: FontWeight.w700)),
                      DropdownButton<PaymentMethod>(
                        value: inv.method, dropdownColor: const Color(0xFFF5F1E6),
                        underline: const SizedBox(),
                        items: PaymentMethod.values.map((m) => DropdownMenuItem(value: m, child: Text(m.label))).toList(),
                        onChanged: (v) => setState(() => inv.method = v!),
                      ),
                      if (inv.txnLast4.isNotEmpty) Text('(عملية ···${inv.txnLast4})', style: const TextStyle(fontSize: 11)),
                    ]),
                    const SizedBox(height: 10),
                    // جدول الأصناف
                    Container(
                      decoration: BoxDecoration(border: Border.all(color: const Color(0xFFB08D2E))),
                      child: Column(children: [
                        Container(
                          color: const Color(0xFFEFE6CC),
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                          child: const Row(children: [
                            Expanded(flex: 3, child: Text('الصنف', style: TextStyle(fontWeight: FontWeight.w800))),
                            Expanded(child: Text('الكمية', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w800))),
                            Expanded(flex: 2, child: Text('السعر', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w800))),
                            Expanded(flex: 2, child: Text('الإجمالي', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w800))),
                            SizedBox(width: 24),
                          ]),
                        ),
                        ...inv.items.asMap().entries.map((e) => Container(
                          decoration: const BoxDecoration(border: Border(top: BorderSide(color: Color(0xFFD8CBA0)))),
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                          child: Row(children: [
                            Expanded(flex: 3, child: Text(e.value.name)),
                            Expanded(child: Text('${e.value.qty}', textAlign: TextAlign.center)),
                            Expanded(flex: 2, child: Text(fmt(e.value.price), textAlign: TextAlign.center)),
                            Expanded(flex: 2, child: Text(fmt(e.value.total), textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700))),
                            SizedBox(width: 24, child: Row(children: [
                              GestureDetector(onTap: () => _editItem(e.key), child: const Icon(Icons.edit, size: 13, color: Color(0xFFB08D2E))),
                              GestureDetector(onTap: () => setState(() => inv.items.removeAt(e.key)),
                                  child: const Icon(Icons.delete_outline, size: 13, color: Colors.red)),
                            ])),
                          ]),
                        )),
                      ]),
                    ),
                    const SizedBox(height: 8),
                    Align(alignment: Alignment.centerRight,
                      child: TextButton.icon(
                        onPressed: () async {
                          final name = TextEditingController(); final qty = TextEditingController(text: '1'); final price = TextEditingController();
                          final r = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
                            backgroundColor: AppColors.card,
                            title: const Text('إضافة صف', style: TextStyle(color: AppColors.text, fontSize: 15)),
                            content: Column(mainAxisSize: MainAxisSize.min, children: [
                              TextField(controller: name, decoration: const InputDecoration(labelText: 'الصنف')),
                              const SizedBox(height: 8),
                              TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الكمية')),
                              const SizedBox(height: 8),
                              TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعر')),
                            ]),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء', style: TextStyle(color: AppColors.muted))),
                              TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('إضافة', style: TextStyle(color: AppColors.gold))),
                            ],
                          ));
                          if (r == true && name.text.isNotEmpty) {
                            setState(() => inv.items.add(InvoiceItem(
                                name: name.text.trim(), qty: int.tryParse(qty.text) ?? 1,
                                price: double.tryParse(price.text) ?? 0)));
                          }
                        },
                        icon: const Icon(Icons.add, size: 14, color: Color(0xFFB08D2E)),
                        label: const Text('إضافة صف', style: TextStyle(color: Color(0xFFB08D2E), fontSize: 12)),
                      ),
                    ),
                    const Divider(color: Color(0xFFB08D2E), height: 20),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      const Text('الإجمالي المستحق', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                      Text('${fmt(total)} ج.س', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                    ]),
                    const SizedBox(height: 16),
                    const Text('شروط الإرجاع والاستبدال', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFFB08D2E))),
                    TextField(controller: policy, maxLines: 2,
                        decoration: const InputDecoration(isDense: true, fillColor: Colors.transparent,
                            border: UnderlineInputBorder(), hintText: '')),
                    const SizedBox(height: 18),
                    const Text('التوقيع', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFFB08D2E))),
                    const SizedBox(height: 26),
                    const Center(child: Text('توقيع المستلم / الختم', style: TextStyle(fontSize: 11, color: Colors.black54))),
                    Container(height: 1, color: Colors.black45, margin: const EdgeInsets.symmetric(horizontal: 40)),
                    const SizedBox(height: 18),
                    Center(child: Text('شكراً لتعاملكم معنا — ${s.businessName}', style: const TextStyle(fontSize: 11))),
                    const SizedBox(height: 6),
                    Center(child: Text('OE Smart Business · ${s.developer}',
                        style: const TextStyle(fontSize: 10, color: Colors.black54))),
                  ]),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
