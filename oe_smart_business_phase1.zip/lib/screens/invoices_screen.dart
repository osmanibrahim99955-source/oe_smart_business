import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../core/theme.dart';
import '../core/enums.dart';
import '../widgets/common.dart';
import '../state/app_state.dart';
import '../models/models.dart';
import 'invoice_detail_screen.dart';

class InvoicesScreen extends StatefulWidget {
  const InvoicesScreen({super.key});
  @override
  State<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends State<InvoicesScreen> {
  bool showDebts = false;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final list = showDebts ? s.debts : s.invoices;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('الفواتير', style: TextStyle(color: AppColors.text, fontSize: 20, fontWeight: FontWeight.w800)),
            const Text('أرشيف شامل مع متابعة الديون والآجل', style: TextStyle(color: AppColors.muted, fontSize: 12)),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => showDebts = false),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: !showDebts ? AppColors.gold.withOpacity(0.15) : AppColors.card,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: !showDebts ? AppColors.gold : AppColors.cardBorder),
                    ),
                    child: Text('الأرشيف (${s.invoices.length})',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: !showDebts ? AppColors.gold : AppColors.muted, fontWeight: FontWeight.w700)),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => showDebts = true),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: showDebts ? AppColors.amber.withOpacity(0.15) : AppColors.card,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: showDebts ? AppColors.amber : AppColors.cardBorder),
                    ),
                    child: Text('الديون الآجلة (${s.debts.length})',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: showDebts ? AppColors.amber : AppColors.muted, fontWeight: FontWeight.w700)),
                  ),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            Expanded(
              child: list.isEmpty
                  ? OECard(child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.receipt_long_outlined, color: AppColors.gold, size: 44),
                      const SizedBox(height: 10),
                      Text(showDebts ? 'لا توجد ديون آجلة مسجلة' : 'لا توجد فواتير بعد — ابدأ أول عملية بيع',
                          style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                    ]))
                  : ListView.separated(
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) {
                        final inv = list[i];
                        return GestureDetector(
                          onTap: () => Navigator.push(context,
                              MaterialPageRoute(builder: (_) => InvoiceDetailScreen(invoice: inv))),
                          child: OECard(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12), child: Row(children: [
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('#${inv.id}', style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w800)),
                              const SizedBox(height: 3),
                              Row(children: [
                                const Icon(Icons.calendar_today_outlined, size: 12, color: AppColors.muted),
                                const SizedBox(width: 4),
                                Text(DateFormat('yyyy-MM-dd').format(inv.date), style: const TextStyle(color: AppColors.muted, fontSize: 11)),
                                const SizedBox(width: 10),
                                Icon(inv.method.icon, size: 13, color: inv.method.color),
                                const SizedBox(width: 4),
                                Text('${inv.method.label}${inv.txnLast4.isNotEmpty ? ' ···${inv.txnLast4}' : ''}',
                                    style: TextStyle(color: inv.method.color, fontSize: 11)),
                              ]),
                              if (inv.customerName.isNotEmpty)
                                Text(inv.customerName, style: const TextStyle(color: AppColors.muted, fontSize: 11)),
                            ])),
                            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                              Text('${fmt(inv.total)} ج.س', style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w800)),
                              Text('ربح ${fmt(inv.profit)}',
                                  style: TextStyle(color: inv.profit >= 0 ? AppColors.green : AppColors.red, fontSize: 11)),
                              if (showDebts)
                                TextButton(
                                  onPressed: () => context.read<AppState>().markInvoicePaid(inv.id),
                                  child: const Text('تحصيل ✓', style: TextStyle(color: AppColors.green, fontSize: 12)),
                                ),
                            ]),
                          ])),
                        );
                      }),
            ),
          ]),
        ),
      ),
    );
  }

}
