import 'package:flutter/material.dart';
import '../core/theme.dart';
import 'home_screen.dart';
import 'inventory_screen.dart';
import 'pos_screen.dart';
import 'vault_screen.dart';
import 'invoices_screen.dart';
import 'settings_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeScreen(onOpenInventory: () => setState(() => index = 1)),
      const InventoryScreen(),
      const PosScreen(),
      const VaultScreen(),
      const InvoicesScreen(),
    ];
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        backgroundColor: AppColors.card,
        indicatorColor: AppColors.gold.withOpacity(0.15),
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: AppColors.gold), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2, color: AppColors.gold), label: 'المخزون'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), selectedIcon: Icon(Icons.shopping_cart, color: AppColors.gold), label: 'البيع'),
          NavigationDestination(icon: Icon(Icons.savings_outlined), selectedIcon: Icon(Icons.savings, color: AppColors.gold), label: 'الخزنة'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long, color: AppColors.gold), label: 'الفواتير'),
        ],
      ),
      floatingActionButton: index == 4
          ? FloatingActionButton.extended(
              backgroundColor: AppColors.gold,
              foregroundColor: Colors.black87,
              icon: const Icon(Icons.settings_outlined),
              label: const Text('الإعدادات'),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())),
            )
          : null,
    );
  }
}
