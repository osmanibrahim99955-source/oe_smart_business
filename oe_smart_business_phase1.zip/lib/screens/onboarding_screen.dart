import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'auth_screen.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});
  static const lines = [
    'صُمم هذا النظام ليمنحك السيطرة المالية الكاملة والوضوح التام في إدارة تجارتك يومياً.',
    'يوفر عليك الوقت والجهد، ويحول تعقيدات الحسابات إلى خطوات بسيطة بدقة عالية.',
    'شريكك الرقمي المستمر لنقل أعمالك إلى مستوى أعلى من الاحترافية والنمو.',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            const SizedBox(height: 30),
            const OELogo(size: 96),
            const SizedBox(height: 18),
            const Text('OE Smart Business',
                style: TextStyle(color: AppColors.gold, fontSize: 30, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            const Text('نظام إدارة المخزون والمبيعات والخزنة المالية',
                style: TextStyle(color: AppColors.muted, fontSize: 14)),
            const SizedBox(height: 26),
            ...lines.map((l) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: OECard(
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('✦', style: TextStyle(color: AppColors.gold, fontSize: 18)),
                      const SizedBox(width: 10),
                      Expanded(child: Text(l, style: const TextStyle(color: AppColors.text, fontSize: 14, height: 1.7))),
                    ]),
                  ),
                )),
            const SizedBox(height: 14),
            GoldButton(
              label: 'تسجيل الدخول للبدء',
              icon: Icons.login,
              onPressed: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const AuthScreen())),
            ),
            const SizedBox(height: 16),
            const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.cloud_outlined, color: AppColors.green, size: 18),
              SizedBox(width: 6),
              Flexible(child: Text('مزامنة سحابية آمنة — بياناتك ترجع كاملة على أي هاتف جديد',
                  style: TextStyle(color: AppColors.muted, fontSize: 12))),
            ]),
            const SizedBox(height: 6),
            const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.shield_outlined, color: AppColors.green, size: 18),
              SizedBox(width: 6),
              Flexible(child: Text('ادخل بحساب Google المسجل بهاتفك بنقرة واحدة دون كلمة سر',
                  style: TextStyle(color: AppColors.muted, fontSize: 12))),
            ]),
            const SizedBox(height: 26),
            Container(height: 1, color: AppColors.cardBorder),
            const SizedBox(height: 16),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Text('تطوير: ', style: TextStyle(color: AppColors.muted, fontSize: 13)),
              const Text('Dr.Osman Ebrahim Hassan',
                  style: TextStyle(color: AppColors.gold, fontSize: 13, fontWeight: FontWeight.w700)),
              const SizedBox(width: 8),
              const OELogo(size: 22),
            ]),
            const SizedBox(height: 10),
          ]),
        ),
      ),
    );
  }
}
