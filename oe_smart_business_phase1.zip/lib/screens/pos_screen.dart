import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme.dart';
import '../core/enums.dart';
import '../widgets/common.dart';
import '../state/app_state.dart';
import '../models/models.dart';

class _Line {
  String name; int qty; double price; double cost;
  _Line(this.name, this.qty, this.price, this.cost);
}

class PosScreen extends StatefulWidget {
  const PosScreen({super.key});
  @override
  State<PosScreen> createState() => _PosScreenState();
}

class _PosScreenState extends State<PosScreen> {
  final List<_Line> cart = [];
  final search = TextEditingController();
  final customer = TextEditingController();
  final phone = TextEditingController();
  final txn = TextEditingController();
  PaymentMethod method = PaymentMethod.cash;
  String query = '';

  double get total => cart.fold(0.0, (s, l) => s + l.qty * l.price);
  double get profit => cart.fold(0.0, (s, l) => s + (l.price - l.cost) * l.qty);

  void _add(Product p) {
    final i = cart.indexWhere((l) => l.name == p.name);
    if (i != -1) {
      cart[i].qty++;
    } else {
      cart.add(_Line(p.name, 1, p.salePrice, p.costPrice));
    }
    setState(() {});
  }

  void _checkout(BuildContext context) {
    final s = context.read<AppState>();
    if (cart.isEmpty) { toast(context, 'السلة فارغة', isError: true); return; }
    if (method.isElectronic) {
      if (txn.text.trim().length != 4) {
        toast(context, 'أدخل آخر 4 أرقام من رقم العملية', isError: true);
        return;
      }
      if (s.vaultRefExists(txn.text.trim())) {
        toast(context, '⚠ رقم العملية مستخدم سابقاً — تم رفض العملية', isError: true);
        return;
      }
    }
    final inv = s.checkout(
      lines: cart.map((l) => {'name': l.name, 'qty': l.qty, 'price': l.price, 'cost': l.cost}).toList(),
      customerName: customer.text.trim(),
      customerPhone: phone.text.trim(),
      method: method,
      txnLast4: method.isElectronic ? txn.text.trim() : '',
    );
    setState(() { cart.clear(); txn.clear(); });
    toast(context, '✓ تم إصدار الفاتورة #${inv.id}');
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final found = s.products.where((p) => p.name.contains(query)).toList();
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Expanded(child: Text('نقطة البيع',
                  style: TextStyle(color: AppColors.text, fontSize: 20, fontWeight: FontWeight.w800))),
              GoldButton(label: 'بند خارجي', icon: Icons.inventory_2_outlined, expand: false,
                  onPressed: () async {
                    final r = await showModalBottomSheet<Map<String, dynamic>>(
                        context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                        builder: (_) => const ExternalItemSheet());
                    if (r != null) { cart.add(_Line(r['name'], 1, r['price'], 0)); setState(() {}); }
                  }),
            ]),
            const SizedBox(height: 12),
            TextField(
              controller: search,
              onChanged: (v) => setState(() => query = v),
              decoration: const InputDecoration(hintText: 'ابحث عن صنف في المخزن...',
                  prefixIcon: Icon(Icons.search, color: AppColors.muted)),
            ),
            if (found.isNotEmpty) ...[
              const SizedBox(height: 8),
              SizedBox(
                height: 46,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: found.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (_, i) => ActionChip(
                    backgroundColor: AppColors.card,
                    side: const BorderSide(color: AppColors.cardBorder),
                    label: Text('${found[i].name} · ${fmt(found[i].salePrice)}',
                        style: const TextStyle(color: AppColors.text, fontSize: 12)),
                    onPressed: () => _add(found[i]),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 10),
            // السلة
            OECard(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [
                Icon(Icons.shopping_cart_outlined, color: AppColors.gold),
                SizedBox(width: 8),
                Text('السلة', style: TextStyle(color: AppColors.text, fontWeight: FontWeight.w800)),
              ]),
              if (cart.isEmpty)
                const Padding(padding: EdgeInsets.symmetric(vertical: 10),
                    child: Center(child: Text('اضغط على صنف لإضافته إلى السلة', style: TextStyle(color: AppColors.muted, fontSize: 12)))),
              ...cart.map((l) => Row(children: [
                Expanded(flex: 3, child: Text(l.name, style: const TextStyle(color: AppColors.text, fontSize: 13))),
                IconButton(icon: const Icon(Icons.remove_circle_outline, color: AppColors.muted, size: 18),
                    onPressed: () => setState(() { if (l.qty > 1) l.qty--; else cart.remove(l); })),
                Text('${l.qty}', style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w700)),
                IconButton(icon: const Icon(Icons.add_circle_outline, color: AppColors.green, size: 18),
                    onPressed: () => setState(() => l.qty++)),
                Expanded(flex: 2, child: Text(fmt(l.qty * l.price), textAlign: TextAlign.left,
                    style: const TextStyle(color: AppColors.text, fontSize: 12))),
              ])),
            ])),
            const SizedBox(height: 10),
            const Text('طريقة الدفع', style: TextStyle(color: AppColors.muted, fontSize: 13)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: PaymentMethod.values.map((m) {
              final sel = method == m;
              return GestureDetector(
                onTap: () => setState(() => method = m),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: sel ? m.color.withOpacity(0.15) : AppColors.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: sel ? m.color : AppColors.cardBorder, width: sel ? 1.4 : 1),
                  ),
                  child: Column(children: [
                    Icon(m.icon, color: sel ? m.color : AppColors.muted, size: 20),
                    Text(m.label, style: TextStyle(color: sel ? m.color : AppColors.muted, fontSize: 12, fontWeight: FontWeight.w700)),
                  ]),
                ),
              );
            }).toList()),
            if (method.isElectronic) ...[
              const SizedBox(height: 10),
              TextField(controller: txn, keyboardType: TextInputType.number, maxLength: 4,
                  decoration: const InputDecoration(
                    labelText: 'آخر 4 أرقام من رقم العملية (تُسجل تلقائياً في الخزنة)',
                    hintText: 'مثال: 2635', counterText: '')),
            ],
            const Spacer(),
            Row(children: [
              Expanded(child: TextField(controller: customer, decoration: const InputDecoration(hintText: 'اسم العميل'))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: phone, keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(hintText: 'الهاتف'))),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('الإجمالي: ${fmt(total)} ج.س', style: const TextStyle(color: AppColors.text, fontSize: 14, fontWeight: FontWeight.w700)),
                Text('صافي الربح المتوقع: ${fmt(profit)} ج.س',
                    style: TextStyle(color: profit >= 0 ? AppColors.green : AppColors.red, fontSize: 13)),
              ])),
            ]),
            const SizedBox(height: 10),
            GoldButton(label: 'إتمام البيع وإصدار الفاتورة', icon: Icons.check_circle_outline,
                onPressed: () => _checkout(context)),
            const SizedBox(height: 6),
          ]),
        ),
      ),
    );
  }
}

class ExternalItemSheet extends StatefulWidget {
  const ExternalItemSheet({super.key});
  @override
  State<ExternalItemSheet> createState() => _ExternalItemSheetState();
}

class _ExternalItemSheetState extends State<ExternalItemSheet> {
  final name = TextEditingController();
  final price = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: const BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(top: BorderSide(color: AppColors.cardBorder)),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            IconButton(icon: const Icon(Icons.close, color: AppColors.muted), onPressed: () => Navigator.pop(context)),
            const Spacer(),
            const Text('بند خارجي (غير مسجل بالمخزن)',
                style: TextStyle(color: AppColors.text, fontWeight: FontWeight.w800)),
          ]),
          const SizedBox(height: 12),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم البند *')),
          const SizedBox(height: 12),
          TextField(controller: price, keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'السعر (ج.س) *')),
          const SizedBox(height: 18),
          GoldButton(label: 'إضافة إلى السلة', icon: Icons.add_shopping_cart, onPressed: () {
            if (name.text.trim().isEmpty || (double.tryParse(price.text) ?? 0) <= 0) {
              toast(context, 'أدخل اسم البند والسعر', isError: true);
              return;
            }
            Navigator.pop(context, {'name': name.text.trim(), 'price': double.parse(price.text)});
          }),
          const SizedBox(height: 10),
        ]),
      ),
    );
  }
}
