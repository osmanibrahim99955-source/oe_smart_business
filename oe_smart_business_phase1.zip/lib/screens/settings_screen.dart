import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import '../state/app_state.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final name = TextEditingController();
  late final policy = TextEditingController();
  String type = 'تجارة عامة';
  final types = ['تجارة عامة', 'مواد غذائية', 'قطع غيار', 'ملابس', 'مزرعة', 'أخرى'];

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>();
    name.text = s.businessName;
    policy.text = s.returnPolicy;
    type = s.businessType;
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              IconButton(icon: const Icon(Icons.arrow_back, color: AppColors.muted), onPressed: () => Navigator.pop(context)),
              const Spacer(),
              const Column(children: [
                Text('الإعدادات', style: TextStyle(color: AppColors.text, fontSize: 18, fontWeight: FontWeight.w800)),
                Text('بيانات نشاطك، حسابك، المزامنة والنسخ الاحتياطي', style: TextStyle(color: AppColors.muted, fontSize: 11)),
              ]),
              const SizedBox(width: 12),
              const OELogo(size: 34),
            ]),
            const SizedBox(height: 16),
            OECard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [
                Icon(Icons.storefront_outlined, color: AppColors.gold),
                SizedBox(width: 8),
                Text('بيانات النشاط التجاري', style: TextStyle(color: AppColors.text, fontWeight: FontWeight.w800)),
              ]),
              const SizedBox(height: 14),
              const Text('اسم النشاط', style: TextStyle(color: AppColors.gold, fontSize: 12)),
              const SizedBox(height: 6),
              TextField(controller: name),
              const SizedBox(height: 12),
              const Text('نوع النشاط', style: TextStyle(color: AppColors.gold, fontSize: 12)),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: type, dropdownColor: AppColors.card, decoration: const InputDecoration(),
                items: types.map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
                onChanged: (v) => setState(() => type = v!),
              ),
              const SizedBox(height: 12),
              const Text('شروط الإرجاع الافتراضية بالفاتورة', style: TextStyle(color: AppColors.gold, fontSize: 12)),
              const SizedBox(height: 6),
              TextField(controller: policy, maxLines: 3),
              const SizedBox(height: 16),
              Align(alignment: Alignment.centerLeft,
                child: GoldButton(label: 'حفظ التعديلات', icon: Icons.save_outlined, expand: false,
                    onPressed: () {
                      s.saveProfile(name: name.text.trim(), type: type, policy: policy.text.trim());
                      toast(context, '✓ تم حفظ بيانات النشاط');
                    }),
              ),
            ])),
            const SizedBox(height: 14),
            OECard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [
                Icon(Icons.person_outline, color: AppColors.gold),
                SizedBox(width: 8),
                Text('الحساب والمزامنة السحابية', style: TextStyle(color: AppColors.text, fontWeight: FontWeight.w800)),
              ]),
              const SizedBox(height: 14),
              Row(children: [
                Container(
                  width: 46, height: 46,
                  decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.goldDark),
                  child: const Center(child: Text('O', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w900, fontSize: 20))),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(s.userName, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w700)),
                  Text(s.userEmail, style: const TextStyle(color: AppColors.muted, fontSize: 11)),
                ])),
              ]),
              const SizedBox(height: 12),
              const Text('كل بياناتك (المخزن، الفواتير، الخزنة، الخزنة المالية) محفوظة سحابياً وآمنة بحسابك — سيجل الدخول بنفس الحساب على أي هاتف جديد وسترجع بياناتك كاملة وتلقائياً.',
                  style: TextStyle(color: AppColors.muted, fontSize: 12, height: 1.7)),
              const SizedBox(height: 12),
              GoldButton(label: 'إدارة الحساب (تسجيل الخروج / حذف)', outline: true,
                  onPressed: () => toast(context, 'إدارة الحساب تُفعّل مع Firebase في مرحلة المزامنة')),
            ])),
            const SizedBox(height: 14),
            OECard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [
                Icon(Icons.download_outlined, color: AppColors.gold),
                SizedBox(width: 8),
                Text('التصدير والنسخ الاحتياطي اليدوي', style: TextStyle(color: AppColors.text, fontWeight: FontWeight.w800)),
              ]),
              const SizedBox(height: 10),
              const Text('حفظ مزدوج: ذاكرة الجهاز المحلية + المزامنة السحابية بحساب Google + خيار تصدير ملف خارجي (JSON) يضم كل الأصناف والفواتير وعمليات الخزنة، يُحفظ على جهازك.',
                  style: TextStyle(color: AppColors.muted, fontSize: 12, height: 1.7)),
              const SizedBox(height: 14),
              Align(alignment: Alignment.centerLeft,
                child: GoldButton(label: 'تصدير نسخة احتياطية الآن', icon: Icons.download, expand: false,
                    onPressed: () => toast(context, 'التصدير الكامل JSON يُفعّل مع طبقة SQLite/الملفات'))),
            ])),
            const SizedBox(height: 14),
            OECard(child: Row(children: [
              const OELogo(size: 40),
              const SizedBox(width: 12),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('OE Smart Business', style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.w800)),
                Text('تطوير وإشراف: Dr.Osman Ebrahim Hassan', style: TextStyle(color: AppColors.muted, fontSize: 11)),
              ])),
              const Icon(Icons.verified_outlined, color: AppColors.green),
            ])),
            const SizedBox(height: 20),
          ]),
        ),
      ),
    );
  }
}
