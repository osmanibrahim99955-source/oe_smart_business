import 'dart:async';
import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import '../state/app_state.dart';
import 'onboarding_screen.dart';
import 'main_shell.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 1800), () {
      if (!mounted) return;
      final state = AppStateProvider.of(context);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => state.setupDone ? const MainShell() : const OnboardingScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const OELogo(size: 110),
          const SizedBox(height: 26),
          Text('جارٍ تحميل بياناتك...',
              style: TextStyle(color: AppColors.gold.withOpacity(0.75), fontSize: 16)),
        ]),
      ),
    );
  }
}
