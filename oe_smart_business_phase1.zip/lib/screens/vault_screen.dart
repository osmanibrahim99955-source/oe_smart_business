import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../core/theme.dart';
import '../core/enums.dart';
import '../widgets/common.dart';
import '../state/app_state.dart';

class VaultScreen extends StatelessWidget {
  const VaultScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('خزنة السيولة الإلكترونية', style: TextStyle(color: AppColors.text, fontSize: 19, fontWeight: FontWeight.w800)),
                Text('التقاط آلي للإشعارات مع منع التكرار والتزوير', style: TextStyle(color: AppColors.muted, fontSize: 11)),
              ])),
              GoldButton(label: 'التقاط إشعار', icon: Icons.photo_camera_outlined, expand: false,
                  onPressed: () => showModalBottomSheet(context: context, isScrollControlled: true,
                      backgroundColor: Colors.transparent, builder: (_) => const CaptureSheet())),
            ]),
            const SizedBox(height: 8),
            GoldButton(label: '+ إدخال يدوي', outline: true, expand: false,
                onPressed: () => showModalBottomSheet(context: context, isScrollControlled: true,
                    backgroundColor: Colors.transparent, builder: (_) => const CaptureSheet(manual: true))),
            const SizedBox(height: 14),
            // واردات اليوم
            OECard(child: Column(children: [
              Row(children: const [
                Icon(Icons.calendar_month_outlined, color: AppColors.gold, size: 18),
                SizedBox(width: 6),
                Text('واردات اليوم (العمليات المقبولة)', style: TextStyle(color: AppColors.muted, fontSize: 12)),
              ]),
              const SizedBox(height: 8),
              Text('${fmt(s.todayVaultTotal)} ج.س',
                  style: const TextStyle(color: AppColors.gold, fontSize: 26, fontWeight: FontWeight.w900)),
              Text('${s.todayVault.length} عملية مقبولة اليوم', style: const TextStyle(color: AppColors.muted, fontSize: 11)),
              const SizedBox(height: 12),
              Row(children: VaultApp.values.map((a) => Expanded(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: a.color.withOpacity(0.4))),
                  child: Column(children: [
                    Icon(a.icon, color: a.color, size: 18),
                    Text(a.label, style: TextStyle(color: a.color, fontSize: 11)),
                    Text(fmt(s.todayVault.where((t) => t.app == a).fold(0.0, (x, t) => x + t.amount)),
                        style: const TextStyle(color: AppColors.text, fontSize: 12, fontWeight: FontWeight.w700)),
                  ]),
                ),
              )).toList()),
            ])),
            const SizedBox(height: 12),
            OECard(borderColor: AppColors.green.withOpacity(0.5), child: Row(children: [
              const Icon(Icons.savings_outlined, color: AppColors.green),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('المجموع الكلي الشامل لكل السيولة الإلكترونية', style: TextStyle(color: AppColors.muted, fontSize: 12)),
                Text('${fmt(s.vaultGrand)} ج.س', style: const TextStyle(color: AppColors.green, fontSize: 22, fontWeight: FontWeight.w900)),
              ])),
            ])),
            const SizedBox(height: 16),
            ...VaultApp.values.map((a) {
              final txns = s.vault.where((t) => t.app == a).toList();
              final total = txns.fold(0.0, (x, t) => x + t.amount);
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: OECard(borderColor: a.color.withOpacity(0.5), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Icon(a.icon, color: a.color),
                    const SizedBox(width: 8),
                    Expanded(child: Text(a.label, style: TextStyle(color: a.color, fontWeight: FontWeight.w800))),
                    Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      Text('${fmt(total)} ج.س', style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w800)),
                      Text('${txns.length} عملية مسجلة', style: const TextStyle(color: AppColors.muted, fontSize: 10)),
                    ]),
                  ]),
                  if (txns.isNotEmpty) const Divider(color: AppColors.cardBorder, height: 18),
                  ...txns.take(5).map((t) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(children: [
                      Icon(t.source == 'capture' ? Icons.document_scanner_outlined
                          : t.source == 'sale' ? Icons.shopping_cart_outlined : Icons.edit_outlined,
                          color: AppColors.muted, size: 16),
                      const SizedBox(width: 8),
                      Expanded(child: Text(t.sender.isEmpty ? (t.txnRef.isEmpty ? 'عملية' : '···${t.txnRef}') : t.sender,
                          style: const TextStyle(color: AppColors.text, fontSize: 13))),
                      Text(DateFormat('yyyy-MM-dd').format(t.date), style: const TextStyle(color: AppColors.muted, fontSize: 10)),
                      const SizedBox(width: 8),
                      Text('${fmt(t.amount)} ج.س', style: const TextStyle(color: AppColors.text, fontSize: 13, fontWeight: FontWeight.w700)),
                    ]),
                  )),
                ])),
              );
            }),
            const SizedBox(height: 10),
          ]),
        ),
      ),
    );
  }
}

class CaptureSheet extends StatefulWidget {
  final bool manual;
  const CaptureSheet({super.key, this.manual = false});
  @override
  State<CaptureSheet> createState() => _CaptureSheetState();
}

class _CaptureSheetState extends State<CaptureSheet> {
  VaultApp app = VaultApp.bankak;
  final amount = TextEditingController();
  final ref = TextEditingController();
  final sender = TextEditingController();
  final note = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final s = context.read<AppState>();
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: const BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(top: BorderSide(color: AppColors.cardBorder)),
        ),
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              IconButton(icon: const Icon(Icons.close, color: AppColors.muted), onPressed: () => Navigator.pop(context)),
              const Spacer(),
              Text(widget.manual ? 'إدخال يدوي' : 'التقاط إشعار تحويل',
                  style: const TextStyle(color: AppColors.text, fontSize: 17, fontWeight: FontWeight.w800)),
            ]),
            const SizedBox(height: 4),
            Text('من أي تطبيق جاء الإشعار؟', style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            const SizedBox(height: 10),
            Row(children: VaultApp.values.map((a) {
              final sel = app == a;
              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => app = a),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: sel ? a.color.withOpacity(0.15) : AppColors.bg,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: sel ? a.color : AppColors.cardBorder, width: sel ? 1.6 : 1),
                    ),
                    child: Column(children: [
                      Icon(a.icon, color: sel ? a.color : AppColors.muted),
                      Text(a.label, style: TextStyle(color: sel ? a.color : AppColors.muted, fontWeight: FontWeight.w700)),
                    ]),
                  ),
                ),
              );
            }).toList()),
            if (!widget.manual) ...[
              const SizedBox(height: 14),
              _dashedOption(Icons.photo_camera_outlined, 'التقاط صورة بالكاميرا',
                  'افتح الكاميرا مباشرة لتصوير إشعار التحويل', () {
                toast(context, 'تُفعّل الكاميرا + OCR (Google ML Kit) في المرحلة الثانية');
              }),
              const SizedBox(height: 10),
              _dashedOption(Icons.upload_file_outlined, 'رفع صورة من الملفات',
                  'اختر لقطة شاشة من المعرض أو الإشعارات المحفوظة', () {
                toast(context, 'تُفعّل قراءة الملفات + OCR في المرحلة الثانية');
              }),
              const SizedBox(height: 10),
              Text('سيقرأ التطبيق (${app.label}) والمبلغ ورقم العملية واسم المرسل آلياً من الصورة، ويرفض أي رقم عملية مستخدم سابقاً.',
                  style: const TextStyle(color: AppColors.muted, fontSize: 11, height: 1.6)),
              const Divider(color: AppColors.cardBorder, height: 24),
            ],
            const Text('أو أدخل البيانات يدوياً للمراجعة:', style: TextStyle(color: AppColors.gold, fontSize: 13)),
            const SizedBox(height: 10),
            TextField(controller: amount, keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'المبلغ التحويلي * (ج.س)')),
            const SizedBox(height: 10),
            TextField(controller: ref, keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'آخر 4 أرقام من رقم العملية', hintText: 'مثال: 2635')),
            const SizedBox(height: 10),
            TextField(controller: sender,
                decoration: const InputDecoration(labelText: 'اسم المرسل / الراسل')),
            const SizedBox(height: 10),
            TextField(controller: note, decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)')),
            const SizedBox(height: 18),
            GoldButton(label: widget.manual ? 'حفظ العملية' : 'حفظ بعد المراجعة', icon: Icons.verified_outlined, onPressed: () {
              final amt = double.tryParse(amount.text) ?? 0;
              if (amt <= 0) { toast(context, 'أدخل المبلغ', isError: true); return; }
              if (ref.text.trim().isNotEmpty && s.vaultRefExists(ref.text.trim())) {
                showDialog(context: context, builder: (_) => AlertDialog(
                  backgroundColor: AppColors.card,
                  title: const Text('تم رفض العملية', style: TextStyle(color: AppColors.red)),
                  content: Text('رقم العملية ···${ref.text.trim()} مسجل مسبقاً في الخزنة.\nتم الحماية من التكرار والاحتيال.',
                      style: const TextStyle(color: AppColors.text)),
                  actions: [TextButton(onPressed: () => Navigator.pop(context),
                      child: const Text('حسناً', style: TextStyle(color: AppColors.gold)))],
                ));
                return;
              }
              s.addVaultTxn(app: app, amount: amt, txnRef: ref.text.trim(),
                  sender: sender.text.trim(), source: widget.manual ? 'manual' : 'capture');
              Navigator.pop(context);
              toast(context, '✓ تم تسجيل عملية ${app.label} بقيمة ${fmt(amt)} ج.س');
            }),
            const SizedBox(height: 10),
          ]),
        ),
      ),
    );
  }

  Widget _dashedOption(IconData icon, String title, String sub, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.gold.withOpacity(0.5), style: BorderStyle.solid),
        ),
        child: Column(children: [
          Icon(icon, color: AppColors.gold, size: 30),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(sub, style: const TextStyle(color: AppColors.muted, fontSize: 11)),
        ]),
      ),
    );
  }
}
