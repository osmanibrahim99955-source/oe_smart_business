import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/enums.dart';
import '../models/models.dart';

class AppState extends ChangeNotifier {
  // الهوية التجارية
  String businessName = 'مزرعة ابراهيم حسن';
  String businessType = 'تجارة عامة';
  String returnPolicy = 'البضاعة المباعة لا تُرد ولا تُستبدل بعد 3 أيام من تاريخ الفاتورة.';
  String developer = 'Dr.Osman Ebrahim Hassan';
  bool setupDone = false;

  // الحساب
  String userName = 'Osman Ibrahim';
  String userEmail = 'osmanibrahim99900@gmail.com';

  int _nextInvoice = 1001;
  final List<Product> products = [];
  final List<Invoice> invoices = [];
  final List<VaultTransaction> vault = [];

  Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    setupDone = p.getBool('setupDone') ?? false;
    businessName = p.getString('businessName') ?? businessName;
    businessType = p.getString('businessType') ?? businessType;
    returnPolicy = p.getString('returnPolicy') ?? returnPolicy;
    userName = p.getString('userName') ?? userName;
    userEmail = p.getString('userEmail') ?? userEmail;
    _nextInvoice = p.getInt('nextInvoice') ?? 1001;
    notifyListeners();
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('setupDone', setupDone);
    await p.setString('businessName', businessName);
    await p.setString('businessType', businessType);
    await p.setString('returnPolicy', returnPolicy);
    await p.setString('userName', userName);
    await p.setString('userEmail', userEmail);
    await p.setInt('nextInvoice', _nextInvoice);
  }

  String get nextInvoiceId => 'INV-$_nextInvoice';

  void saveProfile({String? name, String? type, String? policy}) {
    if (name != null) businessName = name;
    if (type != null) businessType = type;
    if (policy != null) returnPolicy = policy;
    _save();
    notifyListeners();
  }

  void completeSetup({required String name, required String type, required String policy}) {
    businessName = name;
    businessType = type;
    returnPolicy = policy;
    setupDone = true;
    _save();
    notifyListeners();
  }

  void setUser({required String name, required String email}) {
    userName = name;
    userEmail = email;
    _save();
    notifyListeners();
  }

  // ---------------- المخزون ----------------
  void addProduct(Product p) {
    products.add(p);
    notifyListeners();
  }

  void updateProduct(Product p) {
    final i = products.indexWhere((e) => e.id == p.id);
    if (i != -1) products[i] = p;
    notifyListeners();
  }

  void deleteProduct(String id) {
    products.removeWhere((e) => e.id == id);
    notifyListeners();
  }

  List<Product> get lowStock =>
      products.where((p) => p.minLevel > 0 && p.quantity <= p.minLevel).toList();

  // ---------------- البيع والفواتير ----------------
  Invoice checkout({
    required List<Map<String, dynamic>> lines, // {name, qty, price, cost}
    required String customerName,
    required String customerPhone,
    required PaymentMethod method,
    String txnLast4 = '',
  }) {
    final items = lines
        .map((l) => InvoiceItem(name: l['name'], qty: l['qty'], price: l['price']))
        .toList();
    final total = items.fold(0.0, (s, i) => s + i.total);
    final profit =
        lines.fold(0.0, (s, l) => s + (l['price'] - l['cost']) * l['qty']);
    final inv = Invoice(
      id: nextInvoiceId,
      date: DateTime.now(),
      customerName: customerName,
      customerPhone: customerPhone,
      items: items,
      method: method,
      txnLast4: txnLast4,
      total: total,
      profit: profit,
      paid: method != PaymentMethod.ajel,
    );
    invoices.insert(0, inv);
    for (final l in lines) {
      final i = products.indexWhere((e) => e.name == l['name']);
      if (i != -1) products[i].quantity -= (l['qty'] as int);
    }
    final vp = method.vaultApp;
    if (vp != null && txnLast4.isNotEmpty) {
      addVaultTxn(app: vp, amount: total, txnRef: txnLast4,
          sender: customerName, source: 'sale');
    }
    _nextInvoice++;
    _save();
    notifyListeners();
    return inv;
  }

  void updateInvoice(Invoice inv) {
    final i = invoices.indexWhere((e) => e.id == inv.id);
    if (i != -1) invoices[i] = inv;
    notifyListeners();
  }

  void markInvoicePaid(String id) {
    final i = invoices.indexWhere((e) => e.id == id);
    if (i != -1) {
      invoices[i].paid = true;
      notifyListeners();
    }
  }

  List<Invoice> get debts =>
      invoices.where((i) => i.method == PaymentMethod.ajel && !i.paid).toList();
  double get debtsTotal => debts.fold(0.0, (s, i) => s + i.total);

  bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  List<Invoice> get _today =>
      invoices.where((i) => _sameDay(i.date, DateTime.now())).toList();
  double get todaySales => _today.fold(0.0, (s, i) => s + i.total);
  double get todayProfit => _today.fold(0.0, (s, i) => s + i.profit);
  int get todayInvoicesCount => _today.length;
  double get monthSales => invoices
      .where((i) => i.date.year == DateTime.now().year && i.date.month == DateTime.now().month)
      .fold(0.0, (s, i) => s + i.total);

  // ---------------- الخزنة ----------------
  bool vaultRefExists(String ref) =>
      ref.isNotEmpty && vault.any((t) => t.txnRef.isNotEmpty && t.txnRef == ref);

  void addVaultTxn({
    required VaultApp app,
    required double amount,
    String txnRef = '',
    String sender = '',
    String source = 'manual',
  }) {
    vault.insert(0, VaultTransaction(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      app: app, amount: amount, txnRef: txnRef, sender: sender,
      date: DateTime.now(), source: source,
    ));
    notifyListeners();
  }

  List<VaultTransaction> get todayVault =>
      vault.where((t) => _sameDay(t.date, DateTime.now())).toList();
  double get todayVaultTotal => todayVault.fold(0.0, (s, t) => s + t.amount);
  double vaultTotal(VaultApp a) => vault.where((t) => t.app == a).fold(0.0, (s, t) => s + t.amount);
  double get vaultGrand => vault.fold(0.0, (s, t) => s + t.amount);
  int vaultCount(VaultApp a) => vault.where((t) => t.app == a).length;
}


class AppStateProvider {
  static AppState of(BuildContext context) => context.read<AppState>();
}
