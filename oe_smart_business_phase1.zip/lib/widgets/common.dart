import 'package:flutter/material.dart';
import '../core/theme.dart';

class OELogo extends StatelessWidget {
  final double size;
  const OELogo({super.key, this.size = 64});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: AppColors.gold, width: size * 0.045),
        boxShadow: const [BoxShadow(color: AppColors.goldDark, blurRadius: 18, spreadRadius: -6)],
      ),
      child: Center(
        child: Text('OE',
            style: TextStyle(
                color: AppColors.gold,
                fontSize: size * 0.38,
                fontWeight: FontWeight.w900,
                letterSpacing: 1)),
      ),
    );
  }
}

class OECard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? borderColor;
  const OECard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.borderColor});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderColor ?? AppColors.cardBorder),
      ),
      child: child,
    );
  }
}

class GoldButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool outline;
  final bool expand;
  const GoldButton({super.key, required this.label, this.onPressed, this.icon, this.outline = false, this.expand = true});
  @override
  Widget build(BuildContext context) {
    final child = Container(
      width: expand ? double.infinity : null,
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 15),
      decoration: outline
          ? BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.gold),
            )
          : BoxDecoration(
              gradient: const LinearGradient(colors: [AppColors.gold, AppColors.goldDark]),
              borderRadius: BorderRadius.circular(16),
              boxShadow: const [BoxShadow(color: AppColors.goldDark, blurRadius: 14, spreadRadius: -6)],
            ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (icon != null) ...[
            Icon(icon, color: outline ? AppColors.gold : Colors.black87, size: 20),
            const SizedBox(width: 8),
          ],
          Text(label,
              style: TextStyle(
                  color: outline ? AppColors.gold : Colors.black87,
                  fontWeight: FontWeight.w800,
                  fontSize: 16)),
        ],
      ),
    );
    return InkWell(onTap: onPressed, borderRadius: BorderRadius.circular(16), child: child);
  }
}

class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color iconColor;
  const StatCard({super.key, required this.label, required this.value, required this.icon, this.iconColor = AppColors.gold});
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: OECard(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(icon, color: iconColor, size: 18),
            const SizedBox(width: 6),
            Expanded(child: Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 12))),
          ]),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(color: AppColors.text, fontSize: 19, fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}

class AppHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final VoidCallback? onSettings;
  const AppHeader({super.key, required this.title, this.subtitle, this.onSettings});
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(8, 10, 8, 4),
        child: Row(children: [
          IconButton(
            icon: const Icon(Icons.settings_outlined, color: AppColors.muted),
            onPressed: onSettings,
          ),
          const Spacer(),
          Column(children: [
            Text(title, style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w800, fontSize: 17)),
            if (subtitle != null)
              Text(subtitle!, style: const TextStyle(color: AppColors.muted, fontSize: 11)),
          ]),
          const SizedBox(width: 12),
          const OELogo(size: 36),
          const SizedBox(width: 8),
        ]),
      ),
      Container(height: 1, color: AppColors.cardBorder),
    ]);
  }
}
